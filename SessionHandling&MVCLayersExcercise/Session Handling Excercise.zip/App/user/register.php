
        <h1><b>Register</b></h1>
        <br/><br/>

        <form method="post">
                <label>Username</label><br/>
                <input type="text" name="username"></br>
                <label>Password</label><br/>
                <input type="password" name="password"></br>
                <label>Confirm password</label><br/>
                <input type="password" name="confirm_password"></br>
                <label>First name</label><br/>
                <input type="text" name="first_name"></br>
                <label>Last name</label><br/>
                <input type="text" name="last_name"></br>
                <label>Age</label><br/>
                <input type="text" name="born_on"></br>
            <input type="submit" name="register" value="register">
        </form>

