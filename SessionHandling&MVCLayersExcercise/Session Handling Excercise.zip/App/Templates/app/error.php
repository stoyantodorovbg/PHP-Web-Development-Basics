<?php /** @var \App\Data\ErrorDTO $data*/ ?>

<h1>Oops, un error occurred :(</h1>

<h3><?= $data->getErrorInfo() ?></h3>