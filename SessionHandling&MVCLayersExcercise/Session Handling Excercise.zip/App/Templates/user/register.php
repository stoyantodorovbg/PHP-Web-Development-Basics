
        <h1><b>Register</b></h1>
        <br/><br/>

        <form method="POST">
                <label>Username</label><br/>
                <input type="text" name="username"></br>
                <label>Password</label><br/>
                <input type="password" name="password"></br>
                <label>Confirm password</label><br/>
                <input type="password" name="confirmPassword"></br>
                <label>First name</label><br/>
                <input type="text" name="firstName"></br>
                <label>Last name</label><br/>
                <input type="text" name="lastName"></br>
                <label>Age</label><br/>
                <input type="text" name="bornOn"></br>
            <input type="submit" name="register" value="register">
        </form>

