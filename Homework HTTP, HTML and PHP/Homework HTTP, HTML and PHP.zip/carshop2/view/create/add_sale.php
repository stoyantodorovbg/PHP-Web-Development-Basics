<div class="form_create">
<form method="post">
    <input type="hidden" name="add_sale" value="add_sale">
    <h2>Car data</h2>
    <label>car make: </label>
    <br/>
    <input type="text" name="car_make">
    <br/><br/>
    <label>model: </label>
    <br/>
    <input type="text" name="car_model">
    <br/><br/>
    <label>year: </label>
    <br/>
    <input type="text" name="car_year">
    <h2>Customer data</h2>
    <label>first name: </label>
    <br/>
    <input type="text" name="first_name">
    <br/><br/>
    <label>last name: </label>
    <br/>
    <input type="text" name="last_name">
    <br/><br/>
    <label>amount: </label>
    <br/>
    <input type="number" name="amount">
    <br/><br/>
    <input type="submit" name="submit" value="submit">
</form>
</div>
