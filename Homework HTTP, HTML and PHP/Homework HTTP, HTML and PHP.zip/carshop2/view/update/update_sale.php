<div class="form">
<form method="post">
    <input type="hidden" name="update_sale" value="update_sale">
    <h2>Update sale data</h2>
    <label>sale id: </label>
    <br/>
    <input type="text" name="sale_id">
    <br/><br/>
    <label>date of sale: </label>
    <br/>
    <input type="text" name="date_time">
    <br/><br/>
    <label>amount: </label>
    <br/>
    <input type="text" name="amount">
    <br/><br/>
    <input type="submit" name="submit" value="submit">
</form>
</div>