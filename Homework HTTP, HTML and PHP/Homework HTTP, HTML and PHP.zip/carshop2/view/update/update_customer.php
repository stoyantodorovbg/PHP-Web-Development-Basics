<div class="form">
<form method="post">
    <input type="hidden" name="update_customer" value="update_customer">
    <h2>Update customer data</h2>
    <label>customer id: </label>
    <br/>
    <input type="text" name="customer_id">
    <br/><br/>
    <label>first name: </label>
    <br/>
    <input type="text" name="first_name">
    <br/><br/>
    <label>last name: </label>
    <br/>
    <input type="text" name="last_name">
    <br/><br/>
    <input type="submit" name="submit" value="submit">
</form>
</div>
