<div class="form">
<form method="post">
    <input type="hidden" name="update_car" value="update_car">
    <h2>Update car data</h2>
    <label>car id: </label>
    <br/>
    <input type="text" name="car_id">
    <br/><br/>
    <label>make: </label>
    <br/>
    <input type="text" name="car_make">
    <br/><br/>
    <label>model: </label>
    <br/>
    <input type="text" name="car_model">
    <br/><br/>
    <input type="submit" name="submit" value="submit">
</form>
</div>
