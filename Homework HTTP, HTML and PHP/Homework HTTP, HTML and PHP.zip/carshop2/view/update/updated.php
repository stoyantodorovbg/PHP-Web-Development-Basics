<?php
echo "$value with ID $id updated.";