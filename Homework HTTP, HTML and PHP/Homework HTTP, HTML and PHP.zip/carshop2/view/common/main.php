<menu>
    <div id="tabs">
        <ul>
            <li><a href="?action=view_sold_cars"><span>Sold cars</span></a></li>
            <li><a href="?action=view_customers"><span>Customers</span></a></li>
            <li><a href="?action=view_sales"><span>Sales</span></a></li>
            <li><a href="?action=add_sale"><span>Add sale</span></a></li>
            <li><a href="?action=update_data"><span>Update data</span></a></li>
        </ul>
    </div>
</menu>
<div class="main">
<form>
	<input class="main"type="text" name="input">
	<input class="main" type="submit" value=" Search "/>
</form>
</div>