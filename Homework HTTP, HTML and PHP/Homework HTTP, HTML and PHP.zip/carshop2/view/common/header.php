<html>
	<head>
		<title>Car Sales App</title>
        <link rel= "stylesheet" href="css/styles.css">
	</head>
	<body>