<footer>
    <div class="footer">
    <p>Created by: Stoyan Todorov</p>
    </div>
    <div class="footer">
    <p>Contact information: <a href="https://softuni.bg/">
            Softuni</a>.</p>
    </div>
</footer
</body>
</html>